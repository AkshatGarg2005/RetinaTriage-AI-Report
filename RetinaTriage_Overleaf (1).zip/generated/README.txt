Benchmark results from RetinaTriage_Benchmark.ipynb (run of 8 October 2026).
If the benchmark is ever rerun, replace every file in this folder with the
new contents of outputs/paper_assets/ and recompile.
